package com.example.londonpost;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import com.example.londonpost.WResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button button;
    private TextView responseText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        giveitShot();
        init();
    }
    private void init() {
        editText = findViewById(R.id.city_name);
        button = findViewById(R.id.city_click);
        responseText = findViewById(R.id.response_text);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchWeatherDetails();

            }
        });
    }
    private void fetchWeatherDetails() {
        //Obtain an instance of Retrofit by calling the static method.
        Retrofit retrofit = NetworkClient.getRetrofitClient();
        /*
        The main purpose of Retrofit is to create HTTP calls from the Java interface based on the annotation associated with each method. This is achieved by just passing the interface class as parameter to the create method
        */
        WeatherAPIs weatherAPIs = retrofit.create(WeatherAPIs.class);
        /*
        Invoke the method corresponding to the HTTP request which will return a Call object. This Call object will used to send the actual network request with the specified parameters
        */
        Call call = weatherAPIs.getWeatherByCity(editText.getText().toString(), "235bef5a99d6bc6193525182c409602c");
        /*
        This is the line which actually sends a network request. Calling enqueue() executes a call asynchronously. It has two callback listeners which will invoked on the main thread
        */
        call.enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                /*This is the success callback. Though the response type is JSON, with Retrofit we get the response in the form of WResponse POJO class
                 */
                if (response.body() != null) {

                    WResponse wResponse = (WResponse) response.body();
                    responseText.setText("Temp: " + wResponse.getMain().getTemp() + "\n " +
                            "Humidity: " + wResponse.getMain().getHumidity() + "\n" +
                            "Pressure: " + wResponse.getMain().getPressure());

                    Log.i("TAGT", wResponse.getMain().getTemp().toString());
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
                /*
                Error callback
                */
            }
        });
    }


    private void giveitShot() {
        //Obtain an instance of Retrofit by calling the static method.
        Retrofit retrofit = NetworkClient.getRetrofitClient();
        /*
        The main purpose of Retrofit is to create HTTP calls from the Java interface based on the annotation associated with each method. This is achieved by just passing the interface class as parameter to the create method
        */
        WeatherAPIs weatherAPIs = retrofit.create(WeatherAPIs.class);
        /*
        Invoke the method corresponding to the HTTP request which will return a Call object. This Call object will used to send the actual network request with the specified parameters
        */

        // prepare call in Retrofit 2.0
        /*
        JSONObject paramObject = new JSONObject();
        try {
            paramObject.put("email", "admin@gmail.com");
            paramObject.put("password", "123456");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        */

        Call <Login>call2 = weatherAPIs.login("admin2@gmail.com","123456");
        Log.i("FFF", "Call2");
        /*
        This is the line which actually sends a network request. Calling enqueue() executes a call asynchronously. It has two callback listeners which will invoked on the main thread
        */
        call2.enqueue(new Callback() {
            @Override
            public void onResponse(Call call2, Response response) {
                /*This is the success callback. Though the response type is JSON, with Retrofit we get the response in the form of WResponse POJO class
                 */
                if (response.body() != null) {
                    //https://stackoverflow.com/questions/55467538/retrofit-2-0-getting-response-code-200-but-not-getting-the-desired-data

                    Log.i("login", response.toString());
                    Login R = (Login) response.body();
                    Log.i("login", R.getSuccess().getClass() .toString());
                    Log.i("login", R.getSuccess().getToken());

                    final Global globalVariable = (Global) getApplicationContext();
                    //Set name and email in global/application context
                    globalVariable.setName(R.getSuccess().getToken());
                    getDetail();
                }
            }
            @Override
            public void onFailure(Call call2, Throwable t) {
                /*
                Error callback
                */
                Log.i("fff", t.fillInStackTrace().getMessage());
            }
        });

    }

    private void getDetail() {
        //Obtain an instance of Retrofit by calling the static method.
        Retrofit retrofit = NetworkClient.getRetrofitClient();
        /*
        The main purpose of Retrofit is to create HTTP calls from the Java interface based on the annotation associated with each method. This is achieved by just passing the interface class as parameter to the create method
        */
        WeatherAPIs weatherAPIs = retrofit.create(WeatherAPIs.class);
        /*
        Invoke the method corresponding to the HTTP request which will return a Call object. This Call object will used to send the actual network request with the specified parameters
        */

        final Global globalVariable = (Global) getApplicationContext();
        final String name  = globalVariable.getName();

        String accessToken = name;
        Log.i("DDD", accessToken);

        // prepare call in Retrofit 2.0
        Call <Detail>call3 = weatherAPIs.getDetail("Bearer " + accessToken);

        /*
        This is the line which actually sends a network request. Calling enqueue() executes a call asynchronously. It has two callback listeners which will invoked on the main thread
        */
        call3.enqueue(new Callback() {
            @Override
            public void onResponse(Call call3, Response response) {
                /*This is the success callback. Though the response type is JSON, with Retrofit we get the response in the form of WResponse POJO class
                 */
                if (response.body() != null) {
                    //https://stackoverflow.com/questions/55467538/retrofit-2-0-getting-response-code-200-but-not-getting-the-desired-data

                    Log.i("detail", response.toString());
                    Detail R = (Detail) response.body();
                    Log.i("detail", R.getSuccess().getEmail());
                    Log.i("detail", R.getSuccess().getId() .toString());

                }
            }
            @Override
            public void onFailure(Call call3, Throwable t) {
                /*
                Error callback
                */
                Log.i("fff", t.fillInStackTrace().getMessage());
            }
        });
    }


}
