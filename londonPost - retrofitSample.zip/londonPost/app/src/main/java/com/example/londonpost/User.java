package com.example.londonpost;

import android.app.Application;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class User extends Application {

    private String someVariable;

    public String getState(){
        return someVariable;
    }
    public void setState(String s){
        this.someVariable = someVariable;
    }

}