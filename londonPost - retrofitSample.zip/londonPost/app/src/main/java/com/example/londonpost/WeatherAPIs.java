package com.example.londonpost;

import java.util.List;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface WeatherAPIs {
    /*
    Get request to fetch city weather.Takes in two parameter-city name and API key.
    */
    @GET("/data/2.5/weather")
    Call< WResponse > getWeatherByCity(@Query("q") String city, @Query("appid") String apiKey);

    /* Over here we are sending a POST request with two fields as POST request body params */
    //@Headers("Content-Type: application/json") This cause an error
    @FormUrlEncoded
    @POST("api/login")
    //Call< Login > login(@Field("email") String email,@Field("password") String password);
    Call< Login > login(@Field("email") String email,@Field("password") String password);
    @POST("api/details")
    Call< Detail > getDetail(@Header("Authorization") String authHeader);

}
